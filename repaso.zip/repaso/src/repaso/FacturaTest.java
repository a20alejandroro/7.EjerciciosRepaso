package repaso;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class FacturaTest {
    
    @Test
    public void test1() {
        Factura factura = new Factura();
        factura.setConsumokWh(150);
        int resultadoEsperado = 9;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
    
    @Test
    public void test2() {
        Factura factura = new Factura();
        factura.setConsumokWh(450);
        int resultadoEsperado = 8;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
    
    @Test
    public void test3() {
        Factura factura = new Factura();
        factura.setConsumokWh(800);
        int resultadoEsperado = 6;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
    
    @Test
    public void test4() {
        Factura factura = new Factura();
        factura.setConsumokWh(1500);
        int resultadoEsperado = 5;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
    
    @Test
    public void test5() {
        Factura factura = new Factura();
        factura.setConsumokWh(2000);
        int resultadoEsperado = 5;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }

    @Test
    public void test6() {
        Factura factura = new Factura();
        factura.setConsumokWh(2500);
        int resultadoEsperado = 0;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }

    @Test
    public void test7() {
        Factura factura = new Factura();
        factura.setConsumokWh(-1);
        int resultadoEsperado = 0;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
    @Test
    public void test8() {
        Factura factura = new Factura();
        factura.setConsumokWh(-1);
        int resultadoEsperado = 9;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }

    @Test
    public void test9() {
        Factura factura = new Factura();
        factura.setConsumokWh(2500);
        int resultadoEsperado = 0;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }

    @Test
    public void test10() {
        Factura factura = new Factura();
        factura.setConsumokWh(2500);
        int resultadoEsperado = 4;
        int resultadoObtenido = factura.calcularPrezokWh();
        Assertions.assertEquals(resultadoEsperado, resultadoObtenido);
    }
}