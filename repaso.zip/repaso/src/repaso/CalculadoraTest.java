package repaso;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculadoraTest {
    
    @Test
    public void testSuma() {
        Calculadora calculadora = new Calculadora();
        int resultado = calculadora.suma(2, 3);
        assertEquals(5, resultado);
    }
    
    @Test
    public void testResta() {
        Calculadora calculadora = new Calculadora();
        int resultado = calculadora.resta(5, 2);
        assertEquals(3, resultado);
    }
    
    @Test
    public void testMultiplicacion() {
        Calculadora calculadora = new Calculadora();
        int resultado = calculadora.multiplicacion(4, 3);
        assertEquals(12, resultado);
    }
    
    @Test
    public void testDivision() throws Exception {
        Calculadora calculadora = new Calculadora();
        int resultado = calculadora.division(10, 2);
        assertEquals(5.0, resultado, 0);
    }
    
    @Test 
    public void testDivisionPorCero() throws Exception {
        Calculadora calculadora = new Calculadora();
        int resultado = calculadora.division(10, 0);
        assertEquals(0, resultado, 0 );
    }
    
}